<?php
// ══════════════════════════════════════════════════════════════════════════
// app/Models/Candidate.php
// ══════════════════════════════════════════════════════════════════════════

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Candidate extends Model
{
    protected $fillable = ['name', 'mobile', 'status', 'last_sent_at', 'send_count'];

    protected $casts = [
        'last_sent_at' => 'datetime',
    ];
}
