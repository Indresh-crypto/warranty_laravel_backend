<?php
namespace App\Http\Controllers;

use App\Models\Candidate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Carbon\Carbon;

class CandidateController extends Controller
{
    // ── GET /api/candidates ─────────────────────────────────────────────
    public function index(Request $request)
    {
        $query = Candidate::query();

        // Status filter
        if ($request->status === 'sent') {
            $query->where('status', 'sent');
        } elseif ($request->status === 'unsent') {
            $query->where('status', 'unsent');
        }

        // Search
        if ($request->filled('search')) {
            $q = $request->search;
            $query->where(function ($qb) use ($q) {
                $qb->where('mobile', 'like', "%{$q}%")
                   ->orWhere('name', 'like', "%{$q}%");
            });
        }

        // Date range (filter by last_sent_at)
        if ($request->filled('from')) {
            $query->where('last_sent_at', '>=', Carbon::parse($request->from)->startOfDay());
        }
        if ($request->filled('to')) {
            $query->where('last_sent_at', '<=', Carbon::parse($request->to)->endOfDay());
        }

        $perPage = $request->input('per_page', 15);
        $paginated = $query->orderByDesc('id')->paginate($perPage);

        // Stats
        $stats = [
            'total'  => Candidate::count(),
            'sent'   => Candidate::where('status', 'sent')->count(),
            'unsent' => Candidate::where('status', 'unsent')->count(),
            'today'  => Candidate::whereDate('last_sent_at', today())->count(),
        ];

        return response()->json([
            'data'  => $paginated->items(),
            'total' => $paginated->total(),
            'stats' => $stats,
        ]);
    }

    // ── POST /api/candidates/import ─────────────────────────────────────
   public function import(Request $request)
   {
    $request->validate([
        'file' => 'required|file|mimes:xlsx,xls,csv',
    ]);

    // Install: composer require phpoffice/phpspreadsheet
    $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load(
        $request->file('file')->getPathname()
    );

    $sheet = $spreadsheet->getActiveSheet()->toArray();
    $header = array_shift($sheet); // first row = headers

    // auto-detect mobile & name column index
    $mobileIdx = 0;
    $nameIdx   = -1;
    foreach ($header as $i => $col) {
        if (preg_match('/mobile|phone|number|contact|whatsapp/i', $col)) $mobileIdx = $i;
        if (preg_match('/name|candidate/i', $col)) $nameIdx = $i;
    }

    $imported = 0;
    $skipped  = 0;

    \DB::transaction(function () use ($sheet, $mobileIdx, $nameIdx, &$imported, &$skipped) {
        foreach ($sheet as $row) {
            $mobile = preg_replace('/\D/', '', $row[$mobileIdx] ?? '');
            if (strlen($mobile) < 10) { $skipped++; continue; }
            if (strlen($mobile) === 10) $mobile = '91' . $mobile;

            if (\App\Models\Candidate::where('mobile', $mobile)->exists()) {
                $skipped++;
                continue;
            }

            \App\Models\Candidate::create([
                'mobile' => $mobile,
                'name'   => $nameIdx >= 0 ? ($row[$nameIdx] ?? null) : null,
                'status' => 'unsent',
            ]);
            $imported++;
        }
    });

    return response()->json([
        'message'  => "Imported {$imported} candidates, skipped {$skipped} duplicates.",
        'imported' => $imported,
        'skipped'  => $skipped,
    ]);
}


public function sendWhatsapp(Request $request)

{

    // ---------------------------------

    // VALIDATION

    // ---------------------------------

    $request->validate([

        'ids'   => 'required|array',

        'ids.*' => 'integer|exists:candidates,id',

    ]);

    // ---------------------------------

    // FETCH CANDIDATES

    // ---------------------------------

    $candidates = \App\Models\Candidate::whereIn('id', $request->ids)

        ->select('id', 'mobile', 'send_count')

        ->get();

    $success = 0;

    $failed  = 0;

    // ---------------------------------

    // LOOP

    // ---------------------------------

    foreach ($candidates as $candidate) {

        try {

            // ✅ Safe mobile formatting

            $mobile = preg_replace('/\D/', '', $candidate->mobile);

            $destination = str_starts_with($mobile, '91') ? $mobile : '91' . $mobile;

            $params = [];

            $response = Http::withHeaders([

                'Cache-Control' => 'no-cache',

                'Content-Type'  => 'application/x-www-form-urlencoded',

                'apikey'        => 'xmzzeoeowfppicbquvp3zupvntzeqh2j',

            ])->asForm()->post('https://api.gupshup.io/wa/api/v1/template/msg', [

                'channel'     => 'whatsapp',

                'source'      => '919372011028',

                'destination' => $destination,

                'src.name'    => 'Goelectronix',

                'template' => json_encode([

                    "id" => "8cd7360b-8f39-43f9-a799-d02ae344cf0e",

                    "params" => $params

                ], JSON_UNESCAPED_SLASHES),

                'message' => json_encode([

                    "type" => "image",

                    "image" => [

                        "link" => "https://media.licdn.com/dms/image/v2/D4D0BAQExgePoZh64lg/company-logo_200_200/company-logo_200_200/0/1706707195923/goelectronix_technologies_private_limited_logo?e=2147483647&v=beta&t=x5psH1cSOKyZVaPyjtvnNu6MHvQmPQWowNF2PVBUUps"

                    ]

                ], JSON_UNESCAPED_SLASHES)

            ]);

            if ($response->successful()) {

                // ✅ SUCCESS UPDATE

                $candidate->update([

                    'status'       => 'sent',

                    'last_sent_at' => now(),

                    'send_count'   => ($candidate->send_count ?? 0) + 1

                ]);

                $success++;

            } else {

                // ❌ FAILED UPDATE

                $candidate->update([

                    'status'       => 'unsent',

                    'last_sent_at' => now(),

                    'send_count'   => ($candidate->send_count ?? 0) + 1

                ]);

                $failed++;

                Log::error("Failed: {$destination} | " . $response->body());

            }

        } catch (\Exception $e) {

            // ❌ EXCEPTION UPDATE

            $candidate->update([

                'status'       => 'unsent',

                'last_sent_at' => now(),

                'send_count'   => ($candidate->send_count ?? 0) + 1

            ]);

            $failed++;

            Log::error("Exception: {$candidate->mobile} | " . $e->getMessage());

        }

    }

    // ---------------------------------

    // FINAL RESPONSE

    // ---------------------------------

    return response()->json([

        'status' => true,

        'message' => 'WhatsApp sending completed',

        'summary' => [

            'total'   => $candidates->count(),

            'success' => $success,

            'failed'  => $failed

        ]

    ]);

}
}
