<?php

namespace App\Http\Controllers;

use App\Models\SubscribedPackage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

use App\Models\Company;
use App\Models\ZohoInvoice;
use App\Models\WarrantyProduct;
use App\Mail\InvoiceCreatedMail;
use App\Models\WarrantyFlowLog;
use Carbon\Carbon;

class SubscribedPackageController extends Controller
{
    public function index(Request $request)
    {
        $query = SubscribedPackage::with(['company', 'package']);

        if ($request->filled('retailer_id')) {
            $query->where('retailer_id', $request->retailer_id);
        }

        if ($request->filled('package_id')) {
            $query->where('package_id', $request->package_id);
        }

        if ($request->filled('company_id')) {
            $query->where('company_id', $request->company_id);
        }

        if ($request->filled('payment_id')) {
            $query->where('payment_id', $request->payment_id);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('start_date')) {
            $query->whereDate('start_date', '>=', $request->start_date);
        }

        if ($request->filled('end_date')) {
            $query->whereDate('end_date', '<=', $request->end_date);
        }

        $limit = $request->get('limit', 20);

        return response()->json([
            'success' => true,
            'data' => $query->orderByDesc('id')->paginate($limit)
        ]);
    }

    // =========================================================


public function buyPackageWithCredit(Request $request)
{
    $validator = Validator::make($request->all(), [

        'company_package_id' => 'required',

        'company_id'         => 'required|exists:companies,id',

        'retailer_id'        => 'required|exists:companies,id',

        'package_id'         => 'required'
    ]);

    if ($validator->fails()) {

        return response()->json([

            'success' => false,

            'errors'  => $validator->errors()

        ], 422);
    }

    DB::beginTransaction();

    try {

        /*
        |--------------------------------------------------------------------------
        | DUPLICATE CHECK
        |--------------------------------------------------------------------------
        */

        $exists = SubscribedPackage::where(
                'retailer_id',
                $request->retailer_id
            )
            ->where(
                'package_id',
                $request->package_id
            )
            ->where('status', 1)
            ->whereDate(
                'end_date',
                '>=',
                Carbon::today()
            )
            ->lockForUpdate()
            ->exists();

        if ($exists) {

            throw new \Exception(
                'Package already active for this retailer.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | FETCH DATA
        |--------------------------------------------------------------------------
        */

        $product = WarrantyProduct::findOrFail(
            $request->package_id
        );

        $company = Company::findOrFail(
            $request->retailer_id
        );

        if (!$product->zoho_id) {

            throw new \Exception(
                'Zoho product mapping not found'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | WALLET BALANCE CHECK
        |--------------------------------------------------------------------------
        */

        $currentWalletBalance =
            (float) ($company->wallet_balance ?? 0);

        if (
            $currentWalletBalance <
            (float) $request->amount
        ) {

            throw new \Exception(
                'Insufficient wallet balance'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | CREATE SUBSCRIPTION
        |--------------------------------------------------------------------------
        */

        $subscription = SubscribedPackage::create([

            'package_id' =>
                $request->package_id,

            'package_name' =>
                $product->name
                ?? 'Subscription Package',

            'company_package_id' =>
                $request->company_package_id,

            'company_id' =>
                $company->company_id,

            'retailer_id' =>
                $request->retailer_id,

            'status' => 1,

            'enroll_max' =>
                $product->enroll_max,

            'balance' =>
                $product->enroll_max,

            'validity_days' =>
                $product->sub_val_days,

            'payment_id' => 0,

            'start_date' =>
                now()->toDateString(),

            'end_date' =>
                now()
                    ->addDays(
                        $product->sub_val_days
                    )
                    ->toDateString(),

            'amount' =>
                $request->amount,

            'payment_mode' =>
                'wallet'
        ]);

        /*
        |--------------------------------------------------------------------------
        | SUBSCRIPTION CODE
        |--------------------------------------------------------------------------
        */

        $subscriptionCode = strtoupper(

            ($company->company_code ?? 'CMP')
            . '-'
            . now()->format('ymd')
            . '-'
            . str_pad(
                $subscription->id,
                5,
                '0',
                STR_PAD_LEFT
            )
        );

        $subscription->update([

            'subscription_code' =>
                $subscriptionCode
        ]);

        $company->update([

            'is_subscribed' => 1
        ]);

        /*
        |--------------------------------------------------------------------------
        | CREATE INVOICE + APPLY CREDIT
        |--------------------------------------------------------------------------
        */

        $controller =
            app(WarrantyPaymentFlowController::class);

        $invoiceResult =
            $controller->createSubscriptionInvoiceWithWallet(

                $subscription,

                $request->company_id,

                $request->retailer_id,

                $request->package_id,

                0,

                $request->amount
            );

        if (empty($invoiceResult['success'])) {

            throw new \Exception(

                $invoiceResult['message']
                ?? 'Invoice creation failed'
            );
        }

        $zohoInvoice =
            $invoiceResult['invoice'];

        /*
        |--------------------------------------------------------------------------
        | UPDATE SUBSCRIPTION
        |--------------------------------------------------------------------------
        */

        $subscription->update([

            'zoho_invoice_id' =>
                $zohoInvoice['invoice_id'],

            'invoice_created_date' =>
                $zohoInvoice['date']
                ?? now()->toDateString(),

            'invoice_status' =>
                'paid',

            'invoice_json' =>
                json_encode($zohoInvoice),

            'payment_json' =>
                json_encode([

                    'payment_mode' => 'wallet',

                    'amount' => $request->amount,

                    'credited' => true
                ]),

            'status' => 1
        ]);

        /*
        |--------------------------------------------------------------------------
        | APPROVE INVOICE
        |--------------------------------------------------------------------------
        */

        $controller->approveZohoInvoice(

            $request->company_id,

            $zohoInvoice['invoice_id'],

            $company->contact_email
        );

        /*
        |--------------------------------------------------------------------------
        | DEDUCT WALLET
        |--------------------------------------------------------------------------
        */

        $newWalletBalance =

            $currentWalletBalance
            - (float) $request->amount;

        if ($newWalletBalance < 0) {

            $newWalletBalance = 0;
        }

        $company->wallet_balance =
            $newWalletBalance;

        $company->save();

        $company->refresh();

        /*
        |--------------------------------------------------------------------------
        | WHATSAPP
        |--------------------------------------------------------------------------
        */

        try {

            $invoiceNumber =
                $zohoInvoice['invoice_number']
                ?? '-';

            $invoiceDate =
                $zohoInvoice['date']
                ?? now()->toDateString();

            $invoiceAmount =
                $zohoInvoice['total']
                ?? $request->amount;

            $invoiceUrl =
                $zohoInvoice['invoice_url']
                ?? (
                    $zohoInvoice['customer_view_url']
                    ?? ''
                );

            $whatsappService =
                app(
                    \App\Services\WhatsappService::class
                );

            /*
            |--------------------------------------------------------------------------
            | 1. INVOICE WHATSAPP
            |--------------------------------------------------------------------------
            */

            $whatsappService
                ->invoiceWhatsapp(

                    $company,

                    $invoiceNumber,

                    $invoiceDate,

                    $invoiceAmount,

                    $invoiceUrl
                );

            /*
            |--------------------------------------------------------------------------
            | 2. SUBSCRIPTION ACTIVATED
            |--------------------------------------------------------------------------
            */

            $whatsappService
                ->sendSubscriptionActivatedWhatsapp(

                    $company,

                    $subscription
                );

            /*
            |--------------------------------------------------------------------------
            | 3. WALLET DEDUCTED
            |--------------------------------------------------------------------------
            */

            $whatsappService
                ->sendWalletDeductedWhatsapp(

                    $company,

                    'WALLET-' . $subscription->id,

                    $request->amount,

                    $subscription->subscription_code
                        ?? 'WM001',

                    now()->format('d-m-Y'),

                    $company->wallet_balance
                        ?? 0
                );

        } catch (\Exception $e) {

            \Log::error(

                'WhatsApp Failed',

                [

                    'subscription_id' =>
                        $subscription->id,

                    'error' =>
                        $e->getMessage()
                ]
            );
        }

        /*
        |--------------------------------------------------------------------------
        | FLOW LOG
        |--------------------------------------------------------------------------
        */

        WarrantyFlowLog::create([

            'payment_id' => 0,

            'device_id' =>
                $subscription->id,

            'invoice_id' =>
                $subscription->zoho_invoice_id,

            'zoho_payment_id' => null,

            'step' =>
                'SUBSCRIPTION_WALLET_CREDIT_APPLIED',

            'status' => 1,

            'response_data' =>
                json_encode([

                    'payment_mode' => 'wallet',

                    'credited' => true,

                    'amount' => $request->amount
                ])
        ]);

        DB::commit();

        return response()->json([

            'success' => true,

            'message' =>
                'Subscription completed successfully.',

            'data' => [

                'subscription_id' =>
                    $subscription->id,

                'subscription_code' =>
                    $subscription->subscription_code,

                'invoice_id' =>
                    $subscription->zoho_invoice_id,

                'payment_mode' =>
                    'wallet',

                'wallet_balance' =>
                    $company->wallet_balance
            ]
        ]);

    } catch (\Exception $e) {

        DB::rollBack();

        \Log::error(

            'SUBSCRIPTION FLOW FAILED',

            [

                'error' =>
                    $e->getMessage(),

                'request' =>
                    $request->all()
            ]
        );

        return response()->json([

            'success' => false,

            'message' =>
                $e->getMessage()

        ], 500);
    }
}



  public function checkActivePlan(Request $request)
{
    $validator = Validator::make($request->all(), [
        'retailer_id' => 'required|exists:companies,id',
        'package_id'  => 'nullable'
    ]);

    if ($validator->fails()) {
        return response()->json([
            'success' => false,
            'errors'  => $validator->errors()
        ], 422);
    }

    try {

        $today = Carbon::today();

        // ==========================================
        // BASE QUERY
        // ==========================================
        $query = SubscribedPackage::with(['package', 'company'])
            ->where('retailer_id', $request->retailer_id)
            ->where('status', 1)
            ->whereDate('end_date', '>=', $today);

        // ==========================================
        // 🔥 FILTER BY PACKAGE IF PROVIDED
        // ==========================================
        if ($request->filled('package_id')) {
            $query->where('package_id', $request->package_id);
        }

        $subscription = $query->orderByDesc('id')->first();

        // ==========================================
        // NO PLAN FOUND
        // ==========================================
        if (!$subscription) {
            return response()->json([
                'success' => true,
                'has_active_plan' => false,
                'message' => 'No active subscription found'
            ]);
        }

        // ==========================================
        // RESPONSE
        // ==========================================
        return response()->json([
            'success' => true,
            'has_active_plan' => true,
            'data' => [
                'subscription_id'   => $subscription->id,
                'subscription_code' => $subscription->subscription_code,

                'package_id'   => $subscription->package_id,
                'package_name' => $subscription->package->name ?? null,

                'start_date' => $subscription->start_date,
                'end_date'   => $subscription->end_date,
                'validity_days' => $subscription->validity_days,

                'balance'    => $subscription->balance,
                'enroll_max' => $subscription->enroll_max,

                'amount' => $subscription->amount,
                'payment_mode' => $subscription->payment_mode,

                'invoice_id' => $subscription->zoho_invoice_id,
                'payment_id' => $subscription->zoho_payment_id,

                'status' => $subscription->status
            ]
        ]);

    } catch (\Exception $e) {

        \Log::error('CHECK ACTIVE PLAN FAILED', [
            'error' => $e->getMessage(),
            'request' => $request->all()
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Something went wrong',
            'error'   => $e->getMessage()
        ], 500);
    }
}


}