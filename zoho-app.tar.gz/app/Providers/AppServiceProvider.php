<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Auth\Notifications\ResetPassword;

use App\Models\WDevice;
use App\Observers\WDeviceObserver;
    
class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        ResetPassword::createUrlUsing(function ($company, string $token) {
            return env('FRONTEND_RESET_URL') .
                "?token={$token}&email={$company->contact_email}";
        });
        
            WDevice::observe(WDeviceObserver::class);

    }


}
