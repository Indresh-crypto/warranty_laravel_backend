<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Carbon\Carbon;
use Mail;
use App\Mail\DailySalesReportMail;
use App\Models\Company;
use App\Models\WDevice;
use DB;

class SendDailySalesReport extends Command
{
    protected $signature = 'report:daily-sales';
    protected $description = 'Send Daily Sales Report to Admin';

    public function handle()
    {
        $today = Carbon::today();

        // Retailer wise sales
        $reportData = WDevice::join('companies', 'companies.id', '=', 'w_devices.retailer_id')
            ->select(
                'companies.business_name',
                'companies.company_code',
                DB::raw('COUNT(w_devices.id) as total_qty'),
                DB::raw('SUM(w_devices.product_price) as total_amount')
            )
            ->whereDate('w_devices.created_at', $today)
            ->groupBy('companies.id', 'companies.business_name', 'companies.company_code')
            ->orderByDesc('total_qty')
            ->get();

        $totalQty = $reportData->sum('total_qty');
        $totalAmount = $reportData->sum('total_amount');

        // Admin emails
        $admins = Company::whereIn('role', [1,2])
            ->whereNotNull('contact_email')
            ->pluck('contact_email')
            ->toArray();

        // Add fixed email
        $admins[] = 'indresh@goelectronix.com';

        // Remove duplicate emails
        $admins = array_unique($admins);

        // Send mail
        Mail::to($admins)->send(
            new DailySalesReportMail($reportData, $totalQty, $totalAmount, $today->format('d M Y'))
        );

        $this->info('Daily sales report sent successfully.');
    }
}