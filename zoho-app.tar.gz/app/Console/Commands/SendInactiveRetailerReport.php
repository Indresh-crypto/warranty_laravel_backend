<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Company;
use App\Models\CompanyEmployee;
use App\Mail\InactiveRetailerMail;
use Mail;
use Carbon\Carbon;

class SendInactiveRetailerReport extends Command
{
    protected $signature = 'report:inactive-retailers';
    protected $description = 'Retailers not active since 2 days';

    public function handle()
    {
        $date = Carbon::now()->subDays(2);

        // Get inactive retailers
        $retailers = Company::where('role', 5)
            ->where('status', 1)
            ->whereDoesntHave('devices', function ($q) use ($date) {
                $q->where('created_at', '>=', $date);
            })
            ->get();

        if ($retailers->isEmpty()) {
            $this->info('No inactive retailers found.');
            return;
        }

        // Group retailers by company_id
        $groupedRetailers = $retailers->groupBy('company_id');

        foreach ($groupedRetailers as $companyId => $companyRetailers) {

            // Company admins
            $companyEmails = Company::where('company_id', $companyId)
                ->whereIn('role', [1,2])
                ->pluck('contact_email')
                ->toArray();

            // Get districts of inactive retailers
            $districts = $companyRetailers->pluck('district')->unique()->toArray();

            // Employees matching district
            $employeeEmails = CompanyEmployee::where('company_id', $companyId)
                ->where(function ($q) use ($districts) {
                    foreach ($districts as $district) {
                        $q->orWhereRaw("FIND_IN_SET(?, district)", [$district]);
                    }
                })
                ->pluck('official_email')
                ->toArray();

          $emails = ['indresh@goelectronix.com'];
    
    Mail::to($emails)->send(
        new InactiveRetailerMail($companyRetailers, 2)
    );

            Mail::to($emails)->send(
                new InactiveRetailerMail($companyRetailers, 2)
            );

            $this->info("Mail sent for company ID: " . $companyId);
        }

        $this->info('Inactive retailer report sent.');
    }
}