<!DOCTYPE html>
<html>

<head>
       <meta charset="UTF-8">
       <title>Extended Warranty Certificate</title>

       <style>
              body {
                     font-family: DejaVu Sans, Arial, Helvetica, sans-serif;
                     background: #f2f2f2;
                     margin: 0;
                     padding: 20px;
              }

              .certificate {
                     width: 800px;
                     margin: auto;
                     background: #ffffff;
                     border: 1px solid #444;
              }

              .header {
                     text-align: center;
                     padding-top: 4px;
                     padding-bottom: 2px;
              }

              .header img {
                     width: 220px;
              }

              .subtitle {
                     font-size: 12px;
                     color: #666;
              }

              .title {
                     text-align: center;
                     color: #081faa;
                     font-size: 18px;
                     font-weight: bold;
                     padding: 10px 0;
              }

              .section {
                     padding: 10px 20px;
              }

              .table {
                     width: 100%;
                     border-collapse: collapse;
                     font-size: 12px;
              }

              .table th {
                     background: #e5e5e5;
                     text-align: left;
                     padding: 8px;
                     font-size: 12px;
              }

              .table td {
                     padding: 6px 8px;
                     vertical-align: top;
              }

              .label {
                     font-weight: bold;
                     width: 35%;
              }

              .footer {
                     border-top: 1px solid #ccc;
                     margin-top: 15px;
                     padding: 10px 20px;
                     font-size: 11px;
                     line-height: 1.5;
              }

              .small {
                     font-size: 11px;
              }

              .table td {
                     padding: 5px 6px;
                     vertical-align: top;
                     word-break: break-word;
              }

              .label {
                     font-weight: bold;
                     width: 35%;
              }

              .value {
                     width: 65%;
                     word-wrap: break-word;
              }
       </style>
</head>

<body>

       <div class="certificate">

              <!-- HEADER -->
              <div class="header">

                     <img src="{{ public_path('logo2.png') }}">

              </div>

              <div class="title">
                     Extended Warranty Certificate
              </div>


              <!-- CUSTOMER + WARRANTY DETAILS -->
              <div class="section">

                     <table class="table">

                            <tr>
                                   <th width="30%">Customer Details</th>
                                   <th width="70%">Warranty Details</th>
                            </tr>

                            <tr>

                                   <td>

                                          <strong>{{ $device->customer->name }}</strong><br>

                                          {{ $device->customer->address ?? '' }}<br>

                                          Email: {{ $device->customer->email }}<br>

                                          Ph: {{ $device->customer->mobile }}

                                   </td>

                                   <td>

                                          <table width="100%" class="small">

                                                 <tr>
                                                         <td class="label">Warranty Pack</td>
                                                        <td class="value">{{ $device->product->name }}</td>
                                                 </tr>
                                                 <tr>
                                                        <td class="label">Item / Device</td>
                                                        <td>{{ $device->category_name }}</td>
                                                 </tr>

                                                 <tr>
                                                        <td class="label">Warranty Type</td>
                                                        <td>Extended Warranty</td>
                                                 </tr>

                                                 <tr>
                                                        <td class="label">Warranty Duration</td>
                                                        <td>{{ $device->product->validity }} Days</td>
                                                 </tr>

                                                 <tr>
                                                        <td class="label">Warranty ID</td>
                                                        <td>{{ $device->w_code }}</td>
                                                 </tr>

                                                 <tr>
                                                        <td class="label">Warranty Start Date</td>
                                                        <td>{{ \Carbon\Carbon::parse($device->created_at)->format('d M
                                                               Y') }}</td>
                                                 </tr>

                                                 <tr>
                                                        <td class="label">Warranty End Date</td>
                                                        <td>{{ \Carbon\Carbon::parse($device->expiry_date)->format('d M
                                                               Y') }}</td>
                                                 </tr>

                                          </table>

                                   </td>

                            </tr>

                     </table>

              </div>


              <!-- DEVICE DETAILS -->
              <div class="section">

                     <table class="table">

                            <tr>
                                   <th colspan="2">Item / Device Details</th>
                            </tr>

                            <tr>
                                   <td class="label">Item / Device</td>
                                   <td>{{ $device->category_name }}</td>
                            </tr>

                            <tr>
                                   <td class="label">Brand</td>
                                   <td>{{ $device->brand_name }}</td>
                            </tr>

                            <tr>
                                   <td class="label">Model</td>
                                   <td>{{ $device->model }}</td>
                            </tr>

                            <tr>
                                   <td class="label">Serial Number</td>
                                   <td>{{ $device->serial }}</td>
                            </tr>

                            <tr>
                                   <td class="label">IMEI / ESN Number</td>
                                   <td>{{ $device->imei1 }}</td>
                            </tr>

                            <tr>
                                   <td class="label">State</td>
                                   <td>{{ $device->state ?? '' }}</td>
                            </tr>

                            <tr>
                                   <td class="label">City</td>
                                   <td>{{ $device->city ?? '' }}</td>
                            </tr>

                            <tr>
                                   <td class="label">Item Purchased From</td>
                                   <td class="value">
                                          {{ $retailer->business_name }},
                                          ({{ $retailer->company_code }}),
                                          {{ $retailer->contact_phone }},
                                          {{ $retailer->address_line1 }}
                                   </td>
                            </tr>
                            <tr>
                                   <td class="label">Item Purchase Date</td>
                                   <td>{{ \Carbon\Carbon::parse($device->created_at)->format('d M Y') }}</td>
                            </tr>

                            <tr>
                                   <td class="label">Coverage Limit</td>
                                   <td>₹ {{ number_format($device->device_price,2) }}</td>
                            </tr>

                     </table>

              </div>


              <!-- COVERAGE -->
              <div class="section">

                     <table class="table">

                            <tr>
                                   <th>Coverage Includes</th>
                            </tr>

                            <tr>
                                   <td>

                                          <table width="100%">
                                                 @php
                                                 $coverages = $device->product->coverages;
                                                 $chunks = $coverages->chunk(3);
                                                 @endphp

                                                 @foreach($chunks as $chunk)
                                                 <tr>
                                                        @foreach($chunk as $c)
                                                        <td style="padding:5px; font-size:12px;">
                                                               • {{ $c->title }}
                                                        </td>
                                                        @endforeach

                                                        {{-- Fill empty columns if less than 3 --}}
                                                        @for($i = $chunk->count(); $i < 3; $i++) <td>
                                   </td>
                                   @endfor
                            </tr>
                            @endforeach
                     </table>

                     </td>
                     </tr>
                     </table>

              </div>


              <!-- TERMS -->
              <div class="footer">

                     <br><br>

                     <strong>GoElectronix Technologies Pvt. Ltd.</strong><br>

                     Corporate Office: Unit No. 403, 4th Floor, Ellora Olearise Plot No. A-786,
                     TTC Industrial Area MIDC, Kopar Khairane, Navi Mumbai, Maharashtra – 400709, India

                     <br>

                     Email: hello@goelectronix.com

              </div>

       </div>

</body>

</html>