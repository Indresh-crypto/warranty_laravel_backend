<?php

namespace App\Jobs;

use App\Models\WDevice;
use App\Models\Company;
use App\Models\WarrantyFlowLog;
use App\Http\Controllers\WarrantyPaymentFlowController;
use Illuminate\Bus\Queueable;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use GuzzleHttp\Client;

class UpdatePayLaterInvoiceJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $payload;
    public $tries = 5;
    public $timeout = 180;

    public function __construct($payload)
    {
        $this->payload = $payload;
    }

    public function handle()
    {
        $required = [
            'payment_id',
            'invoice_id',
            'company_id',
            'retailer_id',
            'amount'
        ];

        foreach ($required as $field) {
            if (empty($this->payload[$field])) {
                throw new \Exception($field . ' missing');
            }
        }

        DB::beginTransaction();

        try {

            $paymentId = $this->payload['payment_id'];
            $invoiceId = $this->payload['invoice_id'];
            $requestAmount = (float) $this->payload['amount'];

            /*
            |--------------------------------------------------------------------------
            | LOAD COMPANY
            |--------------------------------------------------------------------------
            */

            $company = Company::find($this->payload['company_id']);

            if (!$company || !$company->zoho_access_token || !$company->zoho_org_id) {
                throw new \Exception('Company Zoho credentials missing');
            }

            /*
            |--------------------------------------------------------------------------
            | FETCH DEVICES
            |--------------------------------------------------------------------------
            */

            $devices = WDevice::where('invoice_id', $invoiceId)
                ->get();

            if ($devices->isEmpty()) {
                throw new \Exception('No devices found for invoice');
            }

            if ($devices->first()->payment_status == 1) {
                DB::commit();
                return;
            }

            /*
            |--------------------------------------------------------------------------
            | STEP 1 — FETCH INVOICE FIRST (IMPORTANT)
            |--------------------------------------------------------------------------
            */

            $client = new Client();

            $response = $client->get(
                "https://www.zohoapis.in/books/v3/invoices/{$invoiceId}",
                [
                    'headers' => [
                        'Authorization' => 'Zoho-oauthtoken ' . $company->zoho_access_token
                    ],
                    'query' => [
                        'organization_id' => $company->zoho_org_id
                    ]
                ]
            );

            $body = json_decode($response->getBody(), true);

            if (empty($body['invoice'])) {
                throw new \Exception('Invoice fetch failed');
            }

            $invoice = $body['invoice'];
            $balance = (float) $invoice['balance'];

            Log::info('ZOHO INVOICE STATUS', [
                'invoice_id' => $invoiceId,
                'status' => $invoice['status'],
                'balance' => $balance,
                'requested_amount' => $requestAmount
            ]);

            if ($balance <= 0) {
                DB::commit();
                return;
            }

            /*
            |--------------------------------------------------------------------------
            | CALCULATE SAFE AMOUNT
            |--------------------------------------------------------------------------
            */

            $applyAmount = min($balance, $requestAmount);

            /*
            |--------------------------------------------------------------------------
            | STEP 2 — CREATE ZOHO PAYMENT
            |--------------------------------------------------------------------------
            */

            $controller = app(WarrantyPaymentFlowController::class);

            $zohoPayment = $controller->createZohoPayment(
                $this->payload['company_id'],
                $this->payload['retailer_id'],
                $paymentId,
                $applyAmount,
                $invoiceId
            );

            $paymentEntity = $zohoPayment['payment'] ?? null;

            if (!$paymentEntity) {
                Log::error('Zoho Payment Response', $zohoPayment);
                throw new \Exception('Zoho payment failed');
            }

            /*
            |--------------------------------------------------------------------------
            | STEP 3 — FETCH UPDATED INVOICE
            |--------------------------------------------------------------------------
            */

            $response = $client->get(
                "https://www.zohoapis.in/books/v3/invoices/{$invoiceId}",
                [
                    'headers' => [
                        'Authorization' => 'Zoho-oauthtoken ' . $company->zoho_access_token
                    ],
                    'query' => [
                        'organization_id' => $company->zoho_org_id
                    ]
                ]
            );

            $body = json_decode($response->getBody(), true);

            if (empty($body['invoice'])) {
                throw new \Exception('Final invoice fetch failed');
            }

            $finalInvoice = $body['invoice'];

            /*
            |--------------------------------------------------------------------------
            | STEP 4 — UPDATE DEVICES
            |--------------------------------------------------------------------------
            */

            foreach ($devices as $device) {

                $device->update([
                    'invoice_status'      => $finalInvoice['status'],
                    'invoice_json'        => json_encode($finalInvoice),

                    'payment_status'      => 1,
                    'payment_id'          => $paymentId,
                    'razorpay_payment_id' => $paymentId,
                    'zoho_payment_id'     => $paymentEntity['payment_id'],
                    'payment_json'        => json_encode($paymentEntity),

                    'paid_at'             => now(),
                    'status'              => 1,
                    'is_approved'         => 1
                ]);

                WarrantyFlowLog::create([
                    'payment_id' => $paymentId,
                    'device_id'  => $device->id,
                    'step'       => 'PAY_LATER_COMPLETED',
                    'status'     => 1
                ]);
            }

            DB::commit();

        } catch (\Exception $e) {

            DB::rollBack();

            WarrantyFlowLog::create([
                'payment_id'   => $this->payload['payment_id'] ?? null,
                'step'         => 'PAY_LATER_FAILED',
                'status'       => 0,
                'error_message'=> $e->getMessage()
            ]);

            Log::error('UpdatePayLaterInvoiceJob Failed', [
                'error' => $e->getMessage(),
                'payload' => $this->payload
            ]);

            throw $e;
        }
    }
}