<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubscribedPackage extends Model
{
    protected $fillable = [
        'retailer_id',
        'package_id',
        'company_id',
        'subscription_code',
        'agent_payout',
        'company_payout',
        'retailer_out',
        'emp_payout',
        'start_date',
        'end_date',
        'balance',
        'enroll_max',
        'status',
        'last_used_date',
        'payment_id',
        'zoho_payment_id',
        'zoho_invoice_id',
        'payment_mode',
        'company_package_id',
        'amount',
        'invoice_json',
        'payment_json',
        'validity_days',
        'invoice_created_date',
        'invoice_status'
    ];

    protected $casts = [
        'start_date'      => 'date',
        'end_date'        => 'date',
        'last_used_date'  => 'datetime',
        'agent_payout'    => 'decimal:2',
        'company_payout'  => 'decimal:2',
        'retailer_out'    => 'decimal:2',
        'emp_payout'      => 'decimal:2',
        'balance'         => 'integer',
        'status'          => 'integer',
    ];

    public function retailer()
    {
        return $this->belongsTo(Retailer::class, 'retailer_id');
    }

    public function package()
    {
        return $this->belongsTo(WarrantyProduct::class, 'package_id');
    }

    public function company()
    {
        return $this->belongsTo(Company::class, 'company_id');
    }
}